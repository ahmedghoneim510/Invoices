/*! Built with http://stenciljs.com */
(function(namespace,resourcesUrl){"use strict";

})("ionicons");