<div class="row">
    <div class="col">
        <label for="inputName" class="control-label">رقم الفاتورة</label>
        <?php if(isset($invoices->invoice_number)): ?>
            <input type="text" class="form-control" id="inputName" name="invoice_number" title="يرجي ادخال رقم الفاتورة "
                   value="<?php echo e(old('invoice_number',$invoices->invoice_number??'')); ?>"  readonly required>
        <?php else: ?>
        <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['name' => 'invoice_number','value' => $invoices->invoice_number??'','title' => 'يرجي ادخال رقم الفاتورة ','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'invoice_number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoices->invoice_number??''),'title' => 'يرجي ادخال رقم الفاتورة ','required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>

    <div class="col">
        <label>تاريخ الفاتورة</label>
        <input class="form-control fc-datepicker" name="invoice_date" placeholder="YYYY-MM-DD"
               type="text" value="<?php echo e(date('Y-m-d')); ?>" required>
    </div>

    <div class="col">
        <label>تاريخ الاستحقاق</label>
        <input class="form-control fc-datepicker" value="<?php echo e(old('due_date',$invoices->due_date??'')); ?>" name="due_date" placeholder="YYYY-MM-DD"
               type="text" required>
    </div>

</div>


<div class="row">
    <div class="col">
        <label for="inputName" class="control-label">القسم</label>
        <select name="section_id" class="form-control SlectBox" onclick="console.log($(this).val())"
                onchange="console.log('change is firing')">
            <!--placeholder-->
            <option value=""  disabled>حدد القسم</option>
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($section->id); ?>" <?php if(old('section_id', $invoices->section_id??'')==$section->id ): echo 'selected'; endif; ?>><?php echo e($section->section_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col">
        <label for="inputName" class="control-label">المنتج</label>
        <select id="product" name="product" class="form-control">
            <option value="<?php echo e(old('product',$invoices->product??'')); ?>" selected><?php echo e(old('product',$invoices->product??'')); ?></option>
        </select>
    </div>

    <div class="col">
        <label for="inputName" class="control-label">مبلغ التحصيل</label>
        <input type="text" value="<?php echo e(old('amount_collection',$invoices->amount_collection??'')); ?>" class="form-control" id="inputName" name="amount_collection"
               oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
    </div>
</div>




<div class="row">

    <div class="col">
        <label for="inputName" class="control-label">مبلغ العمولة</label>
        <input type="text" class="form-control form-control-lg" id="Amount_Commission"
               name="amount_commission" value="<?php echo e(old('amount_commission',$invoices->amount_commission??'')); ?>" title="يرجي ادخال مبلغ العمولة "
               oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
               required>
    </div>

    <div class="col">
        <label for="inputName" class="control-label">الخصم</label>
        <input type="text" class="form-control form-control-lg" value="<?php echo e(old('discount',$invoices->discount??'') ?? 0); ?>  " id="Discount" name="discount"
               title="يرجي ادخال مبلغ الخصم "
               oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
               required>
    </div>

    <div class="col">
        <label for="inputName" class="control-label">نسبة ضريبة القيمة المضافة</label>
        <select name="rate_vat" id="Rate_VAT" class="form-control" onchange="myFunction()">
            <!--placeholder-->
            <option value=""  <?php if(old('rate_vat', $invoices->rate_vat??'')== ''): echo 'selected'; endif; ?> disabled>حدد نسبة الضريبة</option>
            <option value=" 5%" <?php if(old('rate_vat', $invoices->rate_vat??'')== '5%'): echo 'selected'; endif; ?>>5%</option>
            <option value="10%" <?php if(old('rate_vat', $invoices->rate_vat??'')== '10%'): echo 'selected'; endif; ?>>10%</option>
        </select>
    </div>

</div>
<div class="row">
    <div class="col">
        <label for="inputName" class="control-label">قيمة ضريبة القيمة المضافة</label>
        <input type="text" class="form-control" value="<?php echo e($invoices->value_vat??''); ?>" id="Value_VAT" name="value_vat" readonly>
    </div>

    <div class="col">
        <label for="inputName" class="control-label">الاجمالي شامل الضريبة</label>
        <input type="text" class="form-control" id="Total"  value=" <?php echo e($invoices->total??''); ?>" name="total" readonly>
    </div>
</div>


<div class="row">
    <div class="col">
        <label for="exampleTextarea">ملاحظات</label>
        <textarea class="form-control" id="exampleTextarea"  name="note" rows="3"><?php echo e($invoices->note??''); ?></textarea>
    </div>
</div><br>

<?php if(!isset($invoices->invoice_number) ): ?>
    <p class="text-danger">* صيغة المرفق pdf, jpeg ,.jpg , png </p>
    <h5 class="card-title">المرفقات</h5>

    <div class="col-sm-12 col-md-12">
        <input type="file" name="pic" class="dropify" accept=".pdf,.jpg, .png, image/jpeg, image/png"
               data-height="70" />
    </div><br>
<?php endif; ?>
<br>

<div class="d-flex justify-content-center">
    <button type="submit" class="btn btn-primary">حفظ البيانات</button>
</div>
<?php /**PATH C:\xampp\htdocs\Invoices\resources\views/invoices/_form.blade.php ENDPATH**/ ?>