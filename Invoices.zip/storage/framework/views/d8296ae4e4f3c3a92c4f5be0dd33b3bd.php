<?php if(session()->has($type)): ?>
    <div class="alert alert-<?php echo e($type); ?>">
        <?php echo e(session($type)); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Invoices\resources\views/components/alert.blade.php ENDPATH**/ ?>