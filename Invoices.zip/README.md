<h1>Invoices App</h1>
<p>Simple Invoices App</p>
<p>Technologies used:</p>
<ul>
<li>laravel</li>
<li>php</li>
<li>mysql</li>
<li>bootstrap</li>
<li>jquery</li>
</ul>
<p>Features:</p>
<ul>
<li>CRUD Invoices</li>
<li>CRUD Products</li>
<li>CRUD Sections</li>
<li>CRUD Invoices Details</li>
<li>Permission </li>
<li>Roles</li>
<li>CRUD Users</li>
<li>Invoices Attactchments</li>
<li>Charts</li>
<li>Export PDF</li>
<li>Export Excel</li>
<li>Send Notification</li>
</ul>

<p>License</p>
<p>MIT</p>
<p>By: Ahmed Ghoneim</p>
